# Investment 경제 네트워크와 충격 전파 원천 파일럿

`REPORT-ko.md`의 Stage 0~3은 2026-11-27 KST 기준입니다. 이 압축본에는 거래·공시·사건으로 만든 실제 파생 CSV, 입력의 주소·바이트·SHA-256, 그리고 성과를 입출력하지 않는 변환 스크립트가 있습니다.

## 파생 데이터

- `named_edges_all_vintages.csv`, `named_edges_asof_20240402.csv`는 공급사에서 구매사로 향합니다. `available_utc`는 당시 SEC 접수 시각입니다. 집계 가중치의 단위는 %이고 `weight_basis`를 함께 해석해야 합니다. 미공개 비중은 비어 있습니다. `common_customer.csv`는 고객을 포함한 삼중항입니다.
- `samsung_named_segment_edges.csv`와 `samsung_segment_revenue.csv`는 공급사, 구매 사업부와 공시 보고량을 연결합니다. 품목의 사업부 총 구매 비중과 회사별의 미공개 비중을 별도 열에 둡니다.
- `bea2017_edges.csv`는 BEA Use 표의 거래 흐름입니다. `icio*_y*.csv`는 OECD regular ICIO의 일본·한국·대만·미국 4국 블록입니다. 각 연도·판본을 별도 파일에 둡니다. 분자는 USD 백만 단위 거래액, 분모는 구매자 산업 산출입니다. 동일 코드의 두 축을 정렬한 BEA 표의 행은 상품입니다. BEA 빈 셀은 양수 링크 확인 편의상 0이고, 음수 조정값을 보존했습니다. ICIO 공식 출처 [OECD ICIO](https://www.oecd.org/en/data/datasets/inter-country-input-output-tables.html) 및 [OECD 조건](https://www.oecd.org/en/about/terms-conditions.html).
- `kr_icio_crosswalk.csv`는 Investment V4 최종 앵커의 후보 라벨 매핑입니다. 과거 사건에서 사용할 PIT 테이블이 아닙니다.
- `product_pairs.csv`는 2024-04-02 이전 공시 Item 1의 탐색적 TF-IDF 점수입니다. 전체 325쌍을 유지하여 임의의 경쟁 임계값을 두지 않았습니다. `product_documents.csv`는 포함·제외 문서와 결과입니다. `vendor_coverage.json`은 TNIC·ETNIC 공급자 ZIP의 구조 집계입니다. 공급자 데이터와 기업 식별 키는 해당 원천에서 취득합니다.
- `patent_documents.csv`, `patent_pairs.csv`는 키워드로 고른 USPTO 공보의 표지 기준 예시입니다. 개별 문서의 공개일과 조직을 명시했습니다. 표본 밖으로 특허 존재·부재를 추정할 수 없습니다.
- `bls_work_stoppages_2023_2025.csv`는 BLS 표의 행 단위와 중복 제거 식별자입니다. `event_paths.csv`는 실제 8개 사건의 연결 판정과 공개일·정밀도입니다. `power_scenarios.csv`는 결과 분산과 무관한 독립 사건 수별 80% 검정력의 표준화 최소 효과입니다.

## 재현

1. 현재 CSV를 바로 열 수 있습니다. 동일 원천 재현이 필요하면 `source_manifest.json`의 `raw_name`에 맞춰 `raw/`에 해당 원본을 취득하고 SHA-256을 대조합니다. 갱신형 웹 HTML은 해시가 바뀔 수 있습니다. 원천마다 필요한 기관의 접근 조건과 공시 접수 시각을 따릅니다.
2. Python 3.12, pandas, NumPy, openpyxl, lxml 및 SciPy를 사용했습니다. `scripts/network_io.py`는 OECD ZIP 3개와 BEA XLSX를, `scripts/vendor.py`는 두 Dartmouth ZIP을 사용합니다. `scripts/pilot.py`는 보존된 `filings.json`, 연차공시 HTML, BLS, V4를 사용합니다. `scripts/product.py`는 같은 공시 목록과 HTML을 사용합니다. `scripts/additional.py`는 삼성과 특허 원문을 사용합니다.
3. 압축 해제한 루트에서 `python scripts/network_io.py`처럼 실행합니다. 기존 `derived/`와 출력 구조가 같습니다. `event_paths.csv`는 판독 원장입니다. `scripts/power.py`는 표준화 검정력 수치를 재생성합니다. `scripts/manifest.py`는 원천 파일 전체를 내려받았을 때 로컬 해시와 DART 보존 매니페스트를 확인합니다.
4. `scripts/verify.py`는 이미 포함된 파일의 행 키, PIT 날짜와 수치, 자료 품질 경계를 확인합니다. 두 연속 실행에서 CSV 순서를 바꿀 수 있는 TF-IDF 단어 합산은 공통 단어를 정렬해 고정했습니다.

증거는 `SOURCE_ONLY`입니다. 과거 결과, 가격, NAV, 결과 라벨, 집행 경로가 포함되어 있지 않습니다. 사이트의 Raw HTML·PDF, Dartmouth 원본 및 대형 소스 ZIP은 재배포하지 않고 공식 주소와 해시를 보존했습니다.
