from itertools import combinations
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import json

import pandas as pd

RAW, OUT = Path('raw'), Path('derived')
FR = {(r[0],r[3]):r for r in json.loads(Path('filings.json').read_text())}
SOURCE_T = '2024-04-02'
edge_specs = [
    ('LEA','GM','direct_sales',20.2,'supplier_sales','2023-02-09','customer revenue'),
    ('LEA','F','direct_sales',13.5,'supplier_sales','2023-02-09','customer revenue'),
    ('LEA','STLA','direct_sales',10.3,'supplier_sales','2023-02-09','customer revenue'),
    ('GNTX','GM','oem_and_tier1',10,'supplier_sales','2023-02-22','OEM group includes Tier 1 suppliers'),
    ('ADNT','STLA','direct_sales',12,'supplier_sales','2022-11-22','most significant customers'),
    ('SPR','BA','direct_sales',60,'supplier_sales','2023-02-17','Boeing contracts; 737 fuselage sole source'),
    ('SPR','BA','direct_sales',64,'supplier_sales','2024-02-22','Boeing contracts; 737 fuselage sole source'),
    ('SPR','AIR','direct_sales',22,'supplier_sales','2023-02-17','Airbus contracts; product scope matters'),
    ('SPR','AIR','direct_sales',19,'supplier_sales','2024-02-22','Airbus contracts; product scope matters'),
    ('ATI','BA','direct_sales',None,'unknown','2023-02-24','titanium LTA for airframes and structural components'),
    ('ATI','BA','direct_sales',None,'unknown','2024-02-23','titanium LTA for airframes and structural components'),
    ('HXL','BA','oem_and_tier1',15,'supplier_sales','2024-02-07','12% commercial aerospace; direct and subcontractors pooled'),
    ('HXL','AIR','oem_and_tier1',39,'supplier_sales','2024-02-07','35% commercial aerospace; direct and subcontractors pooled'),
    ('HWM','BA','direct_sales',5,'supplier_third_party_sales','2022-02-14','2021 issuer exposure; stale for 2024 event'),
    ('BA','LUV','direct_purchase',None,'unknown','2023-02-07','737 MAX orders; only Boeing 737 fleet'),
    ('BA','LUV','direct_purchase',None,'unknown','2024-02-06','737 MAX purchase agreements; only Boeing 737 fleet'),
    ('BA','UAL','direct_purchase',None,'unknown','2023-02-16','737 MAX and 787 orders; also Airbus'),
    ('BA','UAL','direct_purchase',None,'unknown','2024-02-29','737 MAX and 787 orders; also Airbus'),
    ('AIR','UAL','direct_purchase',None,'unknown','2024-02-29','Airbus purchase commitments; also Boeing'),
    ('CRUS','AAPL','end_customer',83,'supplier_sales','2023-05-19','multiple contract manufacturers interposed'),
    ('QRVO','AAPL','end_customer',37,'supplier_sales','2023-05-19','multiple contract manufacturers interposed'),
    ('SWKS','AAPL','named_customer',None,'unknown','2023-11-17','key customers list; invoicing and weight unresolved'),
    ('QRVO','005930.KS','direct_sales',12,'supplier_sales','2023-05-19','named customer and percent; Samsung Electronics'),
    ('TSM','CRUS','direct_purchase',None,'unknown','2023-05-19','named principal wafer foundry; no affected site weight'),
    ('GFS','CRUS','direct_purchase',None,'unknown','2023-05-19','wafer supply capacity contract through 2026'),
    ('PG','WMT','direct_sales',15,'supplier_sales','2023-08-04','includes affiliates; most recent as of snapshot'),
    ('CL','WMT','direct_sales',11,'supplier_sales','2024-02-15','includes affiliates'),
    ('KMB','WMT','direct_sales',13,'supplier_sales','2024-02-08','personal care and consumer tissue'),
    ('KHC','WMT','direct_sales',21,'supplier_sales','2024-02-15','includes both segments'),
]
rows = []
for a,b,kind,weight,wt,date,locator in edge_specs:
    reporter = b if kind == 'direct_purchase' else a
    r = FR[reporter,date]
    src = f"https://www.sec.gov/Archives/edgar/data/{r[1]}/{r[6].replace('-','')}/{r[7]}"
    raw = RAW / f'{reporter}_{date}.html'
    rows.append((a,b,kind,weight,wt,r[5],r[4],reporter,r[6],src,sha256(raw.read_bytes()).hexdigest(),locator))
cols = ['supplier','buyer','kind','weight_pct','weight_basis','period_end','available_utc','reporter','accession','url','sha256','basis']
edges=pd.DataFrame(rows,columns=cols).sort_values(['supplier','buyer','available_utc'])
assert not edges.duplicated(['supplier','buyer','available_utc']).any()
edges.to_csv(OUT/'named_edges_all_vintages.csv',index=False)

def snapshot(date):
    valid=edges[(edges.available_utc.str[:10] < date) &
                (pd.to_datetime(date) - pd.to_datetime(edges.period_end)).dt.days.le(550)]
    return valid.groupby(['supplier','buyer'],as_index=False).tail(1).copy()

snap=snapshot(SOURCE_T)
snap.to_csv(OUT/'named_edges_asof_20240402.csv',index=False)
common=[]
for buyer, frame in snap.groupby('buyer'):
    supplier_rows = list(frame.sort_values('supplier').itertuples())
    for a,b in combinations(supplier_rows,2):
        common.append((a.supplier,b.supplier,buyer,a.kind,b.kind,a.weight_pct,b.weight_pct,max(a.available_utc,b.available_utc)))
com=pd.DataFrame(common,columns=['issuer1','issuer2','shared_customer','path1_kind','path2_kind','share1_pct','share2_pct','available_utc'])
com.to_csv(OUT/'common_customer.csv',index=False)

latest = json.load(gzip.open(RAW/'kr_v4_intervals.json.gz', 'rt'))
label_to_icio = {
    '반도체 제조업':'C26','전자부품 제조업':'C26','자동차용 엔진 및 자동차 제조업':'C29','자동차 신품 부품 제조업':'C29',
    '항공기,우주선 및 부품 제조업':'C302T309','선박 및 보트 건조업':'C301','기타 식품 제조업':'C10T12',
    '기초 화학물질 제조업':'C20','기타 화학제품 제조업':'C20','화학섬유 제조업':'C20',
    '의약품 제조업':'C21','기초 의약물질 제조업':'C21','전기 통신업':'J61',
    '종합 소매업':'G','항공 여객 운송업':'H51','해상 운송업':'H50',
    '일반 목적용 기계 제조업':'C28','특수 목적용 기계 제조업':'C28',
    '전동기, 발전기 및 전기 변환 · 공급 · 제어 장치 제조업':'C27','일차전지 및 이차전지 제조업':'C27',
    '절연선 및 케이블 제조업':'C27','석유 정제품 제조업':'C19','통신 및 방송 장비 제조업':'C26',
    '건물 건설업':'F','토목 건설업':'F','1차 철강 제조업':'C24A','1차 비철금속 제조업':'C24B',
    '고무제품 제조업':'C22','플라스틱제품 제조업':'C22'
}
kr=[]
for identifier,observations in latest.items():
    r=observations[-1]
    group = label_to_icio.get(r['label'])
    if r['status'] == 'PREFERRED_SHARE_OF_ANCHORED_COMMON':
        group = None
    kr.append((identifier,r['label'],r['status'],r.get('notice_date'),f'KOR_{group}' if group else None))
mapped=pd.DataFrame(kr, columns=['identifier','kind_label','status','notice_date','icio_candidate'])
mapped.to_csv(OUT/'kr_icio_crosswalk.csv',index=False)

t=pd.read_html(RAW/'bls.html', encoding='utf-8')[0]
date='Work stoppage beginning date'
t[date]=pd.to_datetime(t[date],format='%m/%d/%Y',errors='coerce')
t=t[t[date].dt.year.between(2023,2025)].copy().sort_values(date,kind='stable')
org='Organizations involved'
groups=['Organizations involved','Union acronym','Union Local']
t['campaign_id']=''
for key,g in t.groupby(groups,sort=False):
    previous = None
    for i,row in g.iterrows():
        d=row[date]
        if previous is None or (d-previous).days > 90:
            root=f"{d.date()}-{i}"
        t.loc[i,'campaign_id']=root
        previous=d
assert len(t) == 94
t.drop(columns='Unnamed: 14').to_csv(OUT/'bls_work_stoppages_2023_2025.csv',index=False)

metrics={
 'sec_firm_snapshot':str(SOURCE_T),'unique_pairs_all_vintages':len(edges.drop_duplicates(['supplier','buyer'])),
 'sec_edge_rows':len(edges),'snapshot_pairs':len(snap),'snapshot_nodes':len(set(snap.supplier)|set(snap.buyer)),
 'snapshot_weighted':int(snap.weight_pct.notna().sum()),'snapshot_kind':snap.kind.value_counts().to_dict(),
 'exposures_by_reporters':len(set(snap.reporter)), 'common_customer_triples':len(com),
 'common_customer_distinct_pairs':len(com.drop_duplicates(['issuer1','issuer2'])),
 'kr_v4_universe':len(mapped),'kr_v4_mapped':int(mapped.icio_candidate.notna().sum()),
 'kr_v4_mapped_categories':int(mapped.icio_candidate.nunique()),'kr_v4_pit_admitted':0,
 'bls_raw':len(t), 'bls_campaigns':int(t.campaign_id.nunique()),
 'bls_year_counts':dict(t[date].dt.year.value_counts()),
 'bls_grouped':t[t.duplicated('campaign_id',False)][[org,date,'campaign_id']].astype(str).values.tolist(),
}
(OUT/'pilot_summary.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False,default=int))
print(json.dumps(metrics,indent=2,ensure_ascii=False,default=int))
print(snap[['supplier','buyer','kind','weight_pct']].to_string(index=False))
