from pathlib import Path
from hashlib import file_digest
from urllib.parse import urlparse
import json
import pandas as pd

raw, out = Path("raw"), Path("derived")
gh="https://raw.githubusercontent.com/jaehojung1879-netizen/Investment/3150c70017432e3b73321fbda47ebea226bf8d2b/"
hp="https://hobergphillips.tuck.dartmouth.edu/idata/"
urls={
 "bea_use.xlsx":"https://apps.bea.gov/industry/xls/io-annual/Use_SUT_Framework_2017_DET.xlsx",
 "icio2023.zip":"https://webfs-sti.oecd.org/files/STI-PIE/ICIO/2023/2016-2020_SML.zip",
 "icio2025.zip":"https://webfs-sti.oecd.org/files/STI-PIE/ICIO/2025/2016-2022_SML.zip",
 "icio2026.zip":"https://webfs-sti.oecd.org/files/STI-PIE/ICIO/2026/2020-2024_SML.zip",
 "tnic.zip":hp+"tnic3_data.zip", "etnic.zip":hp+"Etnic3_data.zip",
 "tnic_readme.txt":hp+"Readme_tnic3.txt", "etnic_readme.txt":hp+"Readme_Etnic3.txt",
 "etnic_prelim.txt":hp+"Readme_Etnic_PreliminaryPeriod.txt",
 "bok_pdf.pdf":"https://www.bok.or.kr/fileSrc/portal/79849d0c6c8d4d6b8ef82b221ea06997/1/b4f31e3ae9c14738a266c727c3bb815d.pdf",
 "kr_v4_intervals.json.gz":gh+"data/kr-industry-membership-foundation-v4/state/intervals.json.gz",
 "samsung_2023.pdf":"https://images.samsung.com/is/content/samsung/assets/global/ir/docs/2023_4Q_Interim_Report.pdf",
 "samsung_disclose.html":"https://www.samsung.com/global/ir/reports-disclosures/public-disclosure-view.84175/",
 "bls.html":"https://www.bls.gov/web/wkstp/monthly-listing.htm",
 "spirit_stop.html":"https://www.prnewswire.com/news-releases/spirit-aerosystems-to-suspend-factory-operations-301857718.html",
 "fed_uaw.html":"https://www.federalreserve.gov/econres/notes/feds-notes/tapping-the-brakes-the-effect-of-the-2023-united-auto-workers-strike-on-economic-activity-20240416.html",
 "unp_order.html":"https://www.up.com/press-releases/service/wabtec-battery-electric-nr220128",
 "union_wab.html":"https://www.ueunion.org/wabtec2023",
 "faa_max.html":"https://www.faa.gov/newsroom/faa-halts-boeing-max-production-expansion-improve-quality-control-also-lays-out-extensive",
 "apa_earth.geojson":"https://earthquake.usgs.gov/fdsnws/event/1/query?eventid=us7000m9g4&format=geojson",
 "tsm_earth_initial.htm":"https://www.sec.gov/Archives/edgar/data/1046179/000104617924000034/a20240403.htm",
 "bax_helene.htm":"https://www.sec.gov/Archives/edgar/data/10456/000162828024041545/bax-20240929xex991.htm",
 "boeing_iam_offer.htm":"https://boeing.mediaroom.com/Boeing-Historic-Contract-Offer-and-Tentative-Agreement-with-IAM-Districts-751-W24",
 "iam_boeing_sept.pdf":"https://www.iam751.org/Aero%20Mechanic/2024/September_2024_AeroMechanic_Web.pdf",
 "dart_originals_13.json.gz":gh+"data/kr-industry-membership-foundation-v2/acquired-dart/annual/batch-13/originals.json.gz",
}
dart_receipts=[]
for file in sorted(raw.glob("dart_batch-*.json")):
    name=file.stem.split("dart_",1)[1]
    urls[file.name]=gh+f"data/kr-industry-membership-foundation-v2/acquired-dart/annual/{name}/manifest-originals.json"
    data=json.loads(file.read_text())
    for record in data["records"]:
        target=record["target"]
        v=next(x for x in record["responses"] if x.get("section")=="business_overview")
        dart_receipts.append((target["ticker"],target["fiscalYear"],target["availableFrom"],"|".join(target["receiptNos"]),v["status"],v["sha256"],urls[file.name],v["url"]))
pd.DataFrame(dart_receipts,columns=["ticker","fiscal_year","receipt_date","receipts","http_status_in_archive","section_sha256","archive_manifest_url","viewer_url"]).to_csv(out/"dart_archive_receipts.csv",index=False)
filings=json.loads(Path("filings.json").read_text())
for symbol,cik,form,date,accepted,period,accession,doc in filings:
    urls[f"{symbol}_{date}.html"]=f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession.replace('-','')}/{doc}"
    urls[f"{symbol}.json"]=f"https://data.sec.gov/submissions/CIK{cik:010d}.json"
for r in pd.read_csv(out/"patent_documents.csv").itertuples():
    urls[f"pat_{r.document_number}.pdf"]=r.url
def sha(p):
    with p.open("rb") as f:
        return file_digest(f,"sha256").hexdigest()
data=[]
for fn,url in sorted(urls.items()):
    p=raw/fn
    assert p.is_file(), str(p)
    data.append({"raw_name":fn,"url":url,"bytes":p.stat().st_size,"sha256":sha(p)})
(out/"source_manifest.json").write_text(json.dumps({"observation_date_Asia_Seoul":"2026-11-27","sources":data},indent=2)+"\n")
print("source manifest",len(data),"raw items","DART archive",len(dart_receipts),len({r[0] for r in dart_receipts}),"distinct issuer-year",len({r[:2] for r in dart_receipts}))
