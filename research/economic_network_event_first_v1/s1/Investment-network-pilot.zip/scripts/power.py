from scipy.stats import chi2, norm, t
from scipy.integrate import quad
from scipy.optimize import brentq
import pandas as pd

def power(n, alpha, d):
    critical = t.ppf(1-alpha/2, n-1)
    noncentrality = d * n**0.5
    def density(x):
        bound = critical * (x / (n-1))**0.5
        return (norm.sf(bound-noncentrality) + norm.cdf(-bound-noncentrality))*chi2.pdf(x,n-1)
    return quad(density, chi2.ppf(1e-10,n-1), chi2.ppf(1-1e-10,n-1))[0]

rows = []
for n in (4,5,8,20,30,40,63,90,91,128):
    for alpha in (.05,.025):
        d = brentq(lambda d: power(n, alpha, d)-.8, .001, 5.0)
        rows.append((n,alpha,d))
out=pd.DataFrame(rows,columns=['independent_clusters','two_sided_alpha','mde_sd_80pct'])
out.to_csv('derived/power_scenarios.csv',index=False)
print(out.to_string(index=False))
for d in (.3,.5,.75):
    n=next(n for n in range(4,1000) if power(n,.025,d)>=.8)
    print('d,n', d,n)
