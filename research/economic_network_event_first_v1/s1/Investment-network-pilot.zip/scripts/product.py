from collections import Counter
from pathlib import Path
from itertools import combinations
import json
import math
import re

from lxml import html
import pandas as pd

OUT = Path('derived')
FR = json.loads(Path('filings.json').read_text())
T = '2024-04-02T00:00:00Z'
records = {}
for r in FR:
    if r[4] < T and (r[0] not in records or r[4] > records[r[0]][4]):
        records[r[0]] = r

def source(row):
    return f"https://www.sec.gov/Archives/edgar/data/{row[1]}/{row[6].replace('-', '')}/{row[7]}"

def text(row):
    path = Path('raw',f'{row[0]}_{row[3]}.html')
    raw = html.parse(str(path))
    strings = raw.xpath('//text()[not(ancestor::style) and not(ancestor::script) and not(ancestor::*[name()="ix:header"])]')
    return ' '.join(' '.join(x.split()) for x in strings if x.strip())

start = re.compile(r'\bitem\s+1\.?\s*[:.\-–]*\s*business\b', re.I)
end = re.compile(r'\bitem\s+1a\.?\s*[:.\-–]*\s*risk\s+factors\b', re.I)
omit = set('about after also among been before being between business company could each financial fiscal from have into item made more most other over page report results sale sales segment services some such table than that their them these they this those through under upon using were what when where which while will with would year years ability addition annual based include including limited management operations provided provide related risk statements subject substantially total various'.split())
tokens = {}
meta = []
for t,r in sorted(records.items()):
    raw = text(r)
    ends = list(end.finditer(raw))
    candidates = []
    for m in start.finditer(raw):
        e = next((j for j in ends if j.start()>m.end()),None)
        if e is not None and 3000 <= e.start()-m.end() <= 200000:
            candidates.append(raw[m.end():e.start()])
    s = max(candidates,key=len,default='')
    words=Counter(x for x in re.findall(r'[a-z]{4,}',s.lower()) if x not in omit)
    if len(words) > 100:
        tokens[t]=words
    meta.append((t,r[1],r[2],r[4],len(s),len(words),source(r)))
pd.DataFrame(meta,columns=['ticker','cik','form','acceptance_utc','characters','distinct_tokens','source']).to_csv(OUT/'product_documents.csv',index=False)

df=Counter(x for words in tokens.values() for x in words)
v={t:{k:(1+math.log(n))*(1+math.log((1+len(tokens))/(1+df[k]))) for k,n in w.items() if 2 <= df[k] <= len(tokens)*.8} for t,w in tokens.items()}
norm={t:math.sqrt(sum(i*i for i in w.values())) for t,w in v.items()}
pairs=[]
for t,u in combinations(v,2):
    score=sum(v[t][k]*v[u][k] for k in sorted(v[t].keys() & v[u].keys()))/(norm[t]*norm[u])
    pairs.append((t,u,score))
pair=pd.DataFrame(pairs,columns=['issuer1','issuer2','cosine'])
pair.to_csv(OUT/'product_pairs.csv',index=False)
print('Product',len(records),len(tokens),len(pair))
print(pair.nlargest(12,'cosine').to_string(index=False))
print(pd.DataFrame(meta).loc[lambda x:x[3].isna() | (x[5]<100),[0,2,4,5]].to_string(index=False))
