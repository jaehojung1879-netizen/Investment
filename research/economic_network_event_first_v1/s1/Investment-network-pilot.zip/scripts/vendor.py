from pathlib import Path
from zipfile import ZipFile
import json
import pandas as pd

stats={}
for vendor, file in [('TNIC-3','tnic.zip'),('ETNIC-3','etnic.zip')]:
    archive=ZipFile(Path('raw',file))
    filename = next(f for f in archive.namelist() if f.lower().endswith('data.txt'))
    years=set()
    rows=0
    undirected=0
    ids=set()
    focus_rows=0
    for batch in pd.read_csv(archive.open(filename), sep='\t', chunksize=1000000, dtype={'year':int,'gvkey1':int,'gvkey2':int,'score':float}):
        years.update(batch.year.unique())
        rows+=len(batch)
        focus=batch[batch.year==2023]
        focus_rows+=len(focus)
        undirected+=int((focus.gvkey1 < focus.gvkey2).sum())
        ids.update(focus.gvkey1.unique())
        ids.update(focus.gvkey2.unique())
    stats[vendor]={'min_year':int(min(years)), 'max_year':int(max(years)),'rows_all':rows,'2023_rows':focus_rows,'2023_nonself_pairs':undirected,'2023_gvkeys':len(ids)}
Path('derived/vendor_coverage.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
