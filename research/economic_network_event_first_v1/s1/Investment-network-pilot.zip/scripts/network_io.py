from pathlib import Path
from zipfile import ZipFile
import csv
import io
import json
import re

import numpy as np
import openpyxl
import pandas as pd

RAW = Path("raw")
OUT = Path("derived")
COUNTRIES = {"KOR", "USA", "JPN", "TWN"}
AGGREGATES = {
    "A01": "A01_02", "A02": "A01_02",
    "B05": "B05_06", "B06": "B05_06",
    "B07": "B07_08", "B08": "B07_08",
    "C24A": "C24", "C24B": "C24",
    "C301": "C30", "C302T309": "C30",
}
def harmonize(code):
    country, _, industry = code.partition("_")
    return f"{country}_{AGGREGATES.get(industry, industry)}"

def icio(vintage, year):
    filename = f"raw/icio{vintage}.zip"
    with ZipFile(filename) as archive, archive.open(f"{year}_SML.csv") as member:
        reader = csv.reader(io.TextIOWrapper(member, encoding="utf-8-sig", newline=""))
        header = next(reader)
        positions = [k for k, label in enumerate(header)
                     if label.split("_")[0] in COUNTRIES and
                     label.split("_")[1] not in {"HFCE", "NPISH", "GGFC", "GFCF", "INVNT", "DPABR"}]
        labels = [header[k] for k in positions]
        id_set = set(labels)
        output_column = header.index("OUT")
        flows, output = {}, {}
        for row in reader:
            if row[0] in id_set:
                flows[row[0]] = [float(row[k]) for k in positions]
                output[row[0]] = float(row[output_column])
    assert len(labels) == len(id_set) == len(flows)
    X = pd.DataFrame.from_dict(flows, orient="index", columns=labels).reindex(labels)
    K = pd.Series(output).reindex(labels)
    assert X.notna().all().all() and (K>=0).all(), K[K<0]
    named = X.rename(index=harmonize, columns=harmonize)
    harmonized = named.groupby(level=0).sum().T.groupby(level=0).sum().T
    return X, K, harmonized, K.groupby(harmonize).sum()

def export_flows(data, totals, name, supplier, buyer, units):
    long = data.stack()
    long.index.names = [supplier, buyer]
    rows = long.rename(units).reset_index()
    rows["buyer_output"] = rows[buyer].map(totals)
    rows["input_per_unit_buyer_output"] = rows[units] / rows["buyer_output"].where(rows["buyer_output"] > 0)
    rows = rows[rows[units] != 0].copy()
    rows.to_csv(OUT / f"{name}.csv", index=False)
    return {
        "from_nodes": data.shape[0], "to_nodes": data.shape[1],
        "possible_cells": data.size, "positive": int((rows[units] > 0).sum()),
        "negative": int((rows[units] < 0).sum()), "zeros": data.size - len(rows),
        "positive_offdiag": int(((rows[units] > 0) & (rows[supplier] != rows[buyer])).sum())}

def bea():
    wb = openpyxl.load_workbook(RAW/"bea_use.xlsx", data_only=True, read_only=True)
    sheet = wb["2017"]
    rows = list(sheet.values)
    def code(number):
        return str(number) if number is not None else ""
    codes = [code(x) for x in rows[5]]
    output = dict(zip(codes, rows[413]))
    index = [i for i, c in enumerate(codes) if i >= 2 and c.isalnum() and isinstance(output[c], (int,float)) and output[c] > 0 and not c.startswith(("F","T","V"))]
    buyers = [codes[i] for i in index]
    commodities = dict((code(row[0]), row) for row in rows[6:408] if code(row[0]))
    common = [c for c in buyers if c in commodities]
    assert len(common) == 397 and len(set(common)) == len(common)
    literals = {}
    def val(x):
        if isinstance(x, (int,float)):
            return x
        literals[str(x)] = literals.get(str(x), 0)+1
        if x is None:
            return 0
        raise ValueError(x)
    cols = [codes.index(c) for c in common]
    data = pd.DataFrame([[val(commodities[c][i]) for i in cols] for c in common], index=common, columns=common)
    totals = pd.Series({c: output[c] for c in common})
    pd.DataFrame([{"code":c,"commodity":commodities[c][1],"industry":rows[4][codes.index(c)]} for c in common]).to_csv(OUT/"bea_codes.csv",index=False)
    return data, totals, literals

summary = {}
data, totals, blanks = bea()
summary["bea2017"] = export_flows(data, totals, "bea2017_edges", "commodity", "using_industry", "use_musd")
summary["bea2017"]["cell_literals"] = blanks
panel = {}
for vintage, year in [(2023,2020), (2025,2020), (2026,2020), (2026,2024)]:
    data, totals, harmonized, harmonized_output = icio(vintage, year)
    name = f"icio{vintage}_y{year}"
    summary[name] = export_flows(data, totals, name, "supplier_industry", "buyer_industry", "flow_musd")
    if year == 2020:
        panel[vintage] = (harmonized, harmonized_output)
base, base_output = panel[2023]
paired = []
for year in [2025, 2026]:
    data, out = panel[year]
    codes = sorted(set(base.index) & set(data.index))
    assert len(codes) == 180
    a = base.loc[codes,codes] / base_output.loc[codes]
    b = data.loc[codes,codes] / out.loc[codes]
    cross_border = np.array([[x[:3] != y[:3] for y in codes] for x in codes])
    both = (a > 0) & (b > 0) & cross_border
    changes = ((b-a)*100).where(both).stack().to_numpy()
    summary[f"revision_2023_to_{year}"] = {
        "common_nodes":len(codes), "positive_cross_border_both":len(changes),
        "median_absolute_change_pp":float(np.median(np.abs(changes))),
        "p90_absolute_change_pp":float(np.quantile(np.abs(changes),.9))}
    for source,buyer in [
        ("KOR_C26","USA_C29"),("JPN_C26","KOR_C26"),("TWN_C26","KOR_C26"),
        ("KOR_C24","USA_C29"),("USA_C20","KOR_C21"),("KOR_C10T12","USA_I"),
        ("USA_C29","KOR_C29")]:
        paired.append((year,source,buyer,float(a.loc[source,buyer])*100,float(b.loc[source,buyer])*100))
pd.DataFrame(paired,columns=["comparison_vintage","supplier","buyer","pct_2023_vintage","pct_comparison_vintage"]).to_csv(OUT/"icio_revision.csv",index=False)
(OUT/"io_summary.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
