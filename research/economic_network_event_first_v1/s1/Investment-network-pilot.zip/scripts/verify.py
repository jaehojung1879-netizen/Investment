from pathlib import Path
import json
import pandas as pd

d=Path("derived")
n=pd.read_csv(d/"named_edges_asof_20240402.csv")
assert len(n)==23 and not n.duplicated(["supplier","buyer"]).any()
assert len(set(n.supplier)|set(n.buyer)) == 25
assert n.available_utc.str[:10].lt("2024-04-02").all()
assert n.kind.isin(["direct_sales","direct_purchase"]).sum()==17
assert n.weight_pct.notna().sum()==16
r=pd.read_csv(d/"event_paths.csv")
assert r.root.nunique()==8
assert (len(r[r.flag=="core"]),r[r.flag=="core"].root.nunique())==(9,4)
b=pd.read_csv(d/"bls_work_stoppages_2023_2025.csv")
assert (len(b),b.campaign_id.nunique())==(94,91)
a=pd.read_csv(d/"kr_icio_crosswalk.csv")
assert (len(a),a.icio_candidate.notna().sum(),a.icio_candidate.nunique())==(260,131,18)
p=pd.read_csv(d/"patent_documents.csv")
assert len(p)==14 and p.document_number.is_unique and p.publication_date.lt("2024-04-02").all()
c=pd.read_csv(d/"common_customer.csv")
assert len(c)==17 and len(c.drop_duplicates(["issuer1","issuer2"]))==16
assert len(pd.read_csv(d/"product_pairs.csv"))==325
s=pd.read_csv(d/"samsung_named_segment_edges.csv")
assert len(s)==11 and s.firm_specific_share_pct.isna().all() and s.ticker_reference.notna().sum()==9
for f,k,v in [("bea2017_edges.csv","use_musd",43541),("icio2023_y2020.csv","flow_musd",29106),("icio2025_y2020.csv","flow_musd",36709),("icio2026_y2020.csv","flow_musd",36275),("icio2026_y2024.csv","flow_musd",36569)]:
    u=pd.read_csv(d/f)
    assert (u[k]>0).sum()==v and not u.duplicated(list(u.columns[:2])).any()
q=pd.read_csv(d/"power_scenarios.csv")
assert abs(q.query("independent_clusters==4 and two_sided_alpha==.025").mde_sd_80pct.iloc[0]-2.716)<.001
m=json.loads((d/"source_manifest.json").read_text())
assert len({x['raw_name'] for x in m["sources"]})==len(m["sources"])
assert all(len(x["sha256"])==64 and x["url"].startswith("https://") for x in m["sources"])
print("Verified named edges, dates, events, controls, flow cells, MDE, and source identifiers.")
