from collections import defaultdict
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import pandas as pd

RAW, OUT = Path("raw"), Path("derived")
samsung_url='https://images.samsung.com/is/content/samsung/assets/global/ir/docs/2023_4Q_Interim_Report.pdf'
ir_url='https://www.samsung.com/global/ir/reports-disclosures/public-disclosure-view.84175/'
samsung_rows=[
 ('Qualcomm','QCOM','DX','Mobile AP solutions',18.1,'external'),
 ('MediaTek','2454.TW','DX','Mobile AP solutions',18.1,'external'),
 ('Samsung Electro-Mechanics','009150.KS','DX','Camera module',8.0,'related-party subsidiary'),
 ('Powerlogics','047310.KQ','DX','Camera module',8.0,'external'),
 ('Soulbrain','357780.KQ','DS','Chemicals',15.7,'external'),
 ('DongWoo Fine-Chem',None,'DS','Chemicals',15.7,'private entity / issuer map unresolved'),
 ('SK Siltron',None,'DS','Wafers',13.7,'private entity / issuer map unresolved'),
 ('SUMCO','3436.T','DS','Wafers',13.7,'external'),
 ('Wistron NeWeb','6285.TW','Harman','Communication module',6.1,'external'),
 ('Nvidia','NVDA','Harman','SoC',9.9,'external'),
 ('Intel','INTC','Harman','SoC',9.9,'external'),
]
s=pd.DataFrame(samsung_rows,columns=['supplier_entity','ticker_reference','buyer_segment','input_category','category_pct_of_segments_raw_materials','relationship'])
s['buyer_issuer']='005930.KS'
s['available_public_date']='2024-04-30'
s['available_exchange_session_lower_bound']='2024-05-02'
s['firm_specific_share_pct']=None
s['reporting_period']='2023-12-31'
s['document']=samsung_url
s['date_evidence']=ir_url
s['source_sha256']=sha256((RAW/'samsung_2023.pdf').read_bytes()).hexdigest()
s.to_csv(OUT/'samsung_named_segment_edges.csv',index=False)
s[['ticker_reference','relationship']].to_csv(OUT/'samsung_ticker_references.csv',index=False)
segments=pd.DataFrame([
 ('DX',1699923,65.7),('DS',665945,25.7),('SDC',309754,12.0),('Harman',143885,5.6),
 ('Eliminations',-230152,-9.0),('Consolidated',2589355,100.0)
 ],columns=['segment','revenue_krw100m','reported_pct_consolidated'])
assert segments.revenue_krw100m.iloc[:-1].sum()==segments.revenue_krw100m.iloc[-1]
segments['reporting_period']='2023-12-31'
segments['verified_public_date']='2024-04-30'
segments['document']=samsung_url
segments.to_csv(OUT/'samsung_segment_revenue.csv',index=False)

patents=[
 ('CRUS','10700648','2020-06-30','grant','H03F','Cirrus Logic Inc'),
 ('CRUS','11476805','2022-10-18','grant','H03F','Cirrus Logic Inc'),
 ('CRUS','11881826','2024-01-23','grant','H03F','Cirrus Logic Inc'),
 ('IFX.DE','9941908','2018-04-10','grant','H04B','Infineon Technologies AG'),
 ('IFX.DE','10840951','2020-11-17','grant','H04B','Infineon Technologies AG'),
 ('SWKS','10965021','2021-03-30','grant','H03H','Skyworks Solutions Inc'),
 ('SWKS','20220069850','2022-03-03','application_publication','H04B','Skyworks Solutions Inc'),
 ('SWKS','20230144780','2023-05-11','application_publication','H04B','Skyworks Solutions Inc'),
 ('QRVO','20220069849','2022-03-03','application_publication','H04B','Qorvo US Inc'),
 ('BA','11220069','2022-01-11','grant','B29C','The Boeing Company'),
 ('BA','10518516','2019-12-31','grant','B29C','The Boeing Company'),
 ('HXL','20220009183','2022-01-13','application_publication','B29C','Hexcel Composites Limited'),
 ('HXL','20190233602','2019-08-01','application_publication','C08J','Hexcel Corporation'),
 ('SPR','20210031475','2021-02-04','application_publication','B29D','Spirit AeroSystems Inc'),
]
pat=pd.DataFrame(patents,columns=['issuer_reference','document_number','publication_date','document_kind','selected_cpc_subclass','front_page_organization'])
pat['url']='https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/'+pat.document_number
pat['sha256']=[sha256((RAW/f'pat_{k}.pdf').read_bytes()).hexdigest() for k in pat.document_number]
pat.to_csv(OUT/'patent_documents.csv',index=False)

# One pre-specified example classifier per listed front page, not a full portfolio vector.
profiles=defaultdict(set)
for p in pat.itertuples(): profiles[p.issuer_reference].add(p.selected_cpc_subclass)
pairs=[]
for i,j in combinations(sorted(profiles),2):
    a,b=profiles[i],profiles[j]
    if a&b: pairs.append((i,j,','.join(sorted(a&b)),len(a&b)/len(a|b)))
pd.DataFrame(pairs,columns=['issuer1','issuer2','shared_selected_cpc','sample_jaccard']).to_csv(OUT/'patent_pairs.csv',index=False)
print(len(s),s.ticker_reference.notna().sum(),len(pat),len(profiles),len(pairs))
