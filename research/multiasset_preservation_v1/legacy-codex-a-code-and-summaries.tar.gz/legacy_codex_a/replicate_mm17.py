"""Equation (1)-(3) replication using original 1926-2015 sample and revised French vintage.
This is distinct from the already frozen 1964+ comparison; no candidate is selected.
"""
from analyze import french,save,regression,stats,IN,OUT
import numpy as np
import pandas as pd
ff=french('ff3.zip');daily=french('ff_daily.zip',True)
rv=daily['Mkt-RF'].groupby(daily.index.asfreq('M')).apply(lambda x: float(np.sum((x-x.mean())**2)))
d=ff[['Mkt-RF','RF']].copy();d['lag_rv']=rv.reindex(d.index).shift(1);d=d.loc[:'2015-12'].dropna()
f=d['Mkt-RF'].to_numpy();rf=d['RF'].to_numpy();unscaled=f/d['lag_rv'].to_numpy();c=np.std(f,ddof=1)/np.std(unscaled,ddof=1);vm=c*unscaled
result={'source':'French current 202609 CRSP vintage, original MM working paper sample endpoint 2015-12','sample_start':str(d.index[0]),'sample_end':str(d.index[-1]),'months':len(d),'equation2':'sum demeaned daily excess squared in previous month','market':stats(rf+f,rf),'vol_managed':stats(rf+vm,rf),'regression_eq3':regression(vm,f),'gross_exposure_max':float((c/d['lag_rv']).max()),'c':float(c),'published_working_paper_alpha_pa':.0486,'table1_panelA_MktRF_published_N':1065,'limitations':['revised vintage not the authors exact snapshot','original c uses full sample normalization; not a prospective position rule','no fees/funding/margin applied; leverage means not investor net returns','no equality to journal final version asserted']}
result['alpha_difference_vs_working_paper']=result['regression_eq3']['alpha_pa']-.0486
save('mm17-original-sample.json',result);print(result)
