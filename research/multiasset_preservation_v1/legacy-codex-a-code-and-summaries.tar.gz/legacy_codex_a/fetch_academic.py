from fetch_public import ROOT,fetch
import json,re
names=['Betting-Against-Beta-Equity-Factors-Monthly','Betting-Against-Beta-Original-Paper-Data','Quality-Minus-Junk-Factors-Monthly','Time-Series-Momentum-Factors-Monthly','Time-Series-Momentum-Original-Paper-Data','Value-and-Momentum-Everywhere-Factors-Monthly','Value-and-Momentum-Everywhere-Original-Paper-Data']
urls={n+'.xlsx':'https://www.aqr.com/-/media/AQR/Documents/Insights/Data-Sets/'+n+'.xlsx' for n in names}
for name in ['bab','qmj','tsmom','vam']:
 s=(ROOT/'inputs'/(name+'.html')).read_text()
 for l in sorted(set(re.findall(r'[^\s"<>]+\.pdf(?:\?[^\s"<>]*)?',s))): print('PDFLINK',name,l)
from concurrent.futures import ThreadPoolExecutor
with ThreadPoolExecutor(max_workers=4) as p:r=list(p.map(lambda kv:fetch(*kv),urls.items()))
(ROOT/'outputs'/'academic-acquisition.json').write_text(json.dumps(r,indent=2))
for a in r: print(a['name'],a.get('status',a.get('error')),a.get('bytes'))
