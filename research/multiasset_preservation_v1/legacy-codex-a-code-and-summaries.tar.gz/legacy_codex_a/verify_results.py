"""Independent checks of delivered numbers and evidence scope, no strategy re-execution."""
from pathlib import Path
import json,math,hashlib
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parent;O=R/'outputs'; checks=[]
c=json.loads((O/'c2-analysis.json').read_text())
for r in c['path_table']:
 assert abs(math.log1p(r['c2_cagr'])-math.log1p(r['etf_cagr'])-r['log_growth_gap_pa'])<1e-12
 checks.append('C2 '+r['cost']+' log/arithmetic/Jensen reconciliation')
p=json.loads((O/'public-proxy-strategies.json').read_text());m=pd.read_csv(O/'public-proxy-monthly.csv',index_col=0);w=pd.read_csv(O/'public-proxy-weights.csv',index_col=0)
base=m.MARKET100_0x
for row in p['rows']:
 s=m[row['strategy']+'_'+str(row['cost_multiple'])+'x'];cagr=float(np.exp(np.log1p(s).sum()*12/len(s))-1)
 assert abs(cagr-row['cagr'])<1e-12
 peak=pd.concat([pd.Series([1.]),(1+s).cumprod().reset_index(drop=True)],ignore_index=True);dd=peak/peak.cummax()-1;assert abs(dd.min()-row['mdd'])<1e-12
 assert abs((s-base).mean()*12-row['active_vs_public_market']['mean_pa'])<1e-12
 checks.append(row['strategy']+' '+str(row['cost_multiple'])+'x CAGR/MDD/active direct from saved months')
for name in ['MARKET100','MARKET80_RF20','MARKET60_RF40','TREND12_LONG_CASH','TREND12_LONG_SHORT','VOL_TARGET10_CAP1']:assert abs(w[name]).max()<=1
assert len(w)==747 and w.index[0]=='1964-07' and w.index[-1]=='2026-09'
for cost in range(4):
 rr=[r for r in p['rows'] if r['cost_multiple']==cost and r['strategy']!='MARKET100'];assert all(r['holm_6_p']>=r['active_vs_public_market']['p']-1e-15 for r in rr)
f=json.loads((O/'academic-factors.json').read_text());assert f['factor_family_slots']==13
for r in f['rows']:
 if 'holm_13_p' in r:assert r['holm_13_p']>=r['p']-1e-15
sources=json.loads((O/'source-admission.json').read_text());assert not sources['pdf_signature']['qmj_paper.pdf'];assert sources['pdf_signature']['qmj-springer.pdf']
report={'status':'AUTHOR_VALIDATION_ONLY','independent_implementation_crosschecks':len(checks),'checks':checks,'all_pass':True,'causality':'previous-month signal and RV; original MM full-sample scale explicitly noncausal','repo_wide_checks':'not run: independent research folder only; full repository dependencies/test fixtures are not installed in this execution environment','limitations':'not nonauthor independent approval, not real fills, no internal historical outcomes re-executed'}
(O/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],len(checks),'checks pass')
