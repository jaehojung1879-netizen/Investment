"""User-requested standalone official-public-ETF exploratory calculation.
No pipeline, internal price ledger, C2 calculator, approval or lock imports.
"""
from pathlib import Path
import json,hashlib,math
import numpy as np
import pandas as pd
from scipy.stats import norm
R=Path(__file__).resolve().parent;S=R.parent/'source_reconciliation_v1';C=json.loads((R/'contract.json').read_text())
prices=pd.read_csv(S/'outputs/market-price-source.csv');p={t:prices[prices.ticker==t].set_index('date').sort_index() for t in ['SPY','BIL']};dates=sorted(set(p['SPY'].index)&set(p['BIL'].index));days=[d for d in dates if d.startswith('2025')]
D=pd.read_csv(S/'outputs/tax-2025-matched-distributions.csv');assert len(D)==16
ma=p['SPY']['close'].rolling(200,min_periods=200).mean();rows=[]
for day in days:
 prev=dates[dates.index(day)-1];assert np.isfinite(ma[prev]);rows.append((day,prev,float(p['SPY'].loc[prev,'close']),float(ma[prev])))
SIGNALS={d:float(close>mean) for d,prev,close,mean in rows}
pd.DataFrame(rows,columns=['execution_date','signal_date','signal_close','ma200']).to_csv(R/'signal-audit.csv',index=False)
def fee(notional,k):return max(abs(notional)*.001,1.)*k if abs(notional)>1e-9 else 0.
def run(name,k):
 cash=100000.;qty={'SPY':0,'BIL':0};pending=[];ledger=[];trades=[];prior_month=None
 for i,day in enumerate(days):
  op={t:float(p[t].loc[day,'open']) for t in qty};cl={t:float(p[t].loc[day,'close']) for t in qty}
  # Entitlement belongs to previous-close holder; buying today does not receive it.
  for _,ev in D[D.ex_date==day].iterrows():
   amount=qty[ev.ticker]*float(ev['Total Distribution Per Share (11+12+13)'])
   if amount:pending.append({'ticker':ev.ticker,'amount':amount,'pay_date':ev.payment_date,'ex_date':day})
  released=sum(v['amount'] for v in pending if v['pay_date']<day);cash+=released;pending=[v for v in pending if not v['pay_date']<day]
  target={'SPY':1.,'BIL':0.} if name=='SPY100' else {'SPY':.8,'BIL':.2} if name=='SPY80_BIL20_MONTHLY' else {'SPY':.6,'BIL':.4} if name=='SPY60_BIL40_MONTHLY' else {'SPY':SIGNALS[day],'BIL':1-SIGNALS[day]}
  if name=='BIL100_REFERENCE':target={'SPY':0.,'BIL':1.}
  # MA: reallocate only on changed exposure or initial entry; no gratuitous daily churn.
  changed=(i==0 or (name=='SPY_MA200_BIL_DAILY' and SIGNALS[day]!=SIGNALS[days[i-1]]))
  rebalance=changed or (name in ['SPY80_BIL20_MONTHLY','SPY60_BIL40_MONTHLY'] and day[:7]!=prior_month)
  # SPY100 reinvest paid cash on the next available session, whole shares.
  rebalance=rebalance or (name in ['SPY100','BIL100_REFERENCE'] and released>0)
  if rebalance:
   liquid=cash+sum(qty[t]*op[t] for t in qty);desired={t:int(target[t]*liquid/op[t]) for t in qty}
   for t in qty:
    sell=max(0,qty[t]-desired[t])
    if sell:
     val=sell*op[t];cost=fee(val,k);cash+=val-cost;qty[t]-=sell;trades.append(dict(date=day,ticker=t,side='SELL',shares=sell,price=op[t],cost=cost,notional=val,reason='REBALANCE'))
   deficit={t:max(0,desired[t]-qty[t]) for t in qty};needed=sum(deficit[t]*op[t] for t in qty);scale=min(1,cash/needed) if needed else 0
   # Reserve costs and round down; jointly fund both buys, no sequencing advantage.
   buys={t:int(deficit[t]*scale) for t in qty}
   while sum(buys[t]*op[t]+fee(buys[t]*op[t],k) for t in qty if buys[t])>cash+1e-8:
    t=max(buys,key=lambda t:buys[t]*op[t]);buys[t]-=1
   for t,buy in buys.items():
    if buy:
     val=buy*op[t];cost=fee(val,k);cash-=val+cost;qty[t]+=buy;trades.append(dict(date=day,ticker=t,side='BUY',shares=buy,price=op[t],cost=cost,notional=val,reason='REBALANCE'))
  assert cash>=-1e-7 and all(v>=0 and isinstance(v,int) for v in qty.values())
  if i==len(days)-1:
   for t in qty:
    if qty[t]:
     val=qty[t]*cl[t];cost=fee(val,k);trades.append(dict(date=day,ticker=t,side='SELL',shares=qty[t],price=cl[t],cost=cost,notional=val,reason='PREDECLARED_TERMINAL_CLOSE'));cash+=val-cost;qty[t]=0
  receivable=sum(v['amount'] for v in pending);wealth=cash+sum(qty[t]*cl[t] for t in qty)+receivable
  ledger.append(dict(date=day,wealth=wealth,liquid_cash=cash,unpaid_receivable=receivable,SPY_shares=qty['SPY'],BIL_shares=qty['BIL'],dividend_cash_released=released))
  prior_month=day[:7]
 l=pd.DataFrame(ledger);ts=pd.DataFrame(trades);nav=np.r_[100000.,l.wealth];ret=nav[1:]/nav[:-1]-1;peak=np.maximum.accumulate(nav);dd=nav/peak-1;end=int(dd.argmin());start=int(nav[:end+1].argmax());years=(pd.Timestamp(days[-1])-pd.Timestamp(days[0])).days/365.2425
 sd=ret.std(ddof=1);down=np.sqrt(np.mean(np.minimum(ret,0)**2));st={'strategy':name,'cost_multiple':k,'holding_return':float(nav[-1]/nav[0]-1),'cagr_calendar':float((nav[-1]/nav[0])**(1/years)-1),'arithmetic_return_pa':float(ret.mean()*252),'sharpe_zero_cash':float(ret.mean()/sd*np.sqrt(252)),'sortino_zero_MAR':float(ret.mean()/down*np.sqrt(252)),'vol_pa':float(sd*np.sqrt(252)),'mdd':float(dd.min()),'worst_daily_return':float(ret.min()),'drawdown_start':'ENTRY' if start==0 else days[start-1],'drawdown_trough':'ENTRY' if end==0 else days[end-1],'terminal_cash':float(l.iloc[-1].liquid_cash),'unpaid_receivable':float(l.iloc[-1].unpaid_receivable),'terminal_wealth':float(nav[-1]),'cost_dollars':float(ts.cost.sum()),'orders':len(ts),'one_way_turnover':float(ts.notional.sum()/2/100000/years)}
 l.to_csv(R/f'{name}-{k}x-daily.csv',index=False);ts.to_csv(R/f'{name}-{k}x-trades.csv',index=False)
 return st,ret,l

def hac(x,lag=21):
 n=len(x);m=x.mean();d=x-m;v=np.dot(d,d)/n
 for k in range(1,lag+1):v+=2*(1-k/(lag+1))*np.dot(d[k:],d[:-k])/n
 se=np.sqrt(max(v,0)/n);return float(2*norm.sf(abs(m/se))) if se else 1.
def main():
 results=[];paths={};monthly=[]
 for name in C['strategies']:
  for k in [1,2,3]:
   st,ret,l=run(name,k);results.append(st);paths[name,k]=ret
   for month,g in l.groupby(l.date.str[:7]):
    first=int(g.index[0]);before=100000 if first==0 else float(l.iloc[first-1].wealth);monthly.append({'strategy':name,'cost_multiple':k,'month':month,'return':float(g.iloc[-1].wealth/before-1)})
 funding={k:run('BIL100_REFERENCE',k)[1] for k in [1,2,3]}
 rng=np.random.default_rng(20261110);n=len(days);starts=rng.integers(0,n,size=(9999,math.ceil(n/21)));ix=((starts[:,:,None]+np.arange(21))%n).reshape(9999,-1)[:,:n]
 for st in results:
  name,k=st['strategy'],st['cost_multiple'];ex=paths[name,k]-paths['SPY100',k];boot=ex[ix].mean(axis=1)*252;st.update(active_arithmetic_pa=float(ex.mean()*252),active_conditional_bootstrap_ci95=list(np.quantile(boot,[.025,.975]).astype(float)),active_HAC21_p=hac(ex),beta_vs_SPY=float(np.cov(paths[name,k],paths['SPY100',k])[0,1]/np.var(paths['SPY100',k],ddof=1)))
  funding_excess=paths[name,k]-funding[k];st['arithmetic_excess_vs_funded_BIL_pa']=float(funding_excess.mean()*252);st['sharpe_vs_funded_BIL']=float(funding_excess.mean()/funding_excess.std(ddof=1)*np.sqrt(252))
  # Full-sample lower-risk matching by scaling the higher-risk daily path with zero-interest cash. Descriptive only.
  a=paths[name,k];b=paths['SPY100',k];f=funding[k];vol=min((a-f).std(),(b-f).std());aa=f+(a-f)*vol/(a-f).std();bb=f+(b-f)*vol/(b-f).std();st['equal_vol_descriptive_holding_gap']=float(np.prod(1+aa)-np.prod(1+bb))
 for k in [1,2,3]:
  rr=[r for r in results if r['cost_multiple']==k and r['strategy']!='SPY100'];pairs=sorted([(r['active_HAC21_p'],r) for r in rr],key=lambda v:v[0]);prev=0
  for rank,(pval,r) in enumerate(pairs):prev=max(prev,min(1,(24-rank)*pval));r['holm24_p']=prev
 pd.DataFrame(results).to_csv(R/'summary.csv',index=False);pd.DataFrame(monthly).to_csv(R/'monthly.csv',index=False)
 report={'scope':C['evidence'],'contract_sha256':hashlib.sha256((R/'contract.json').read_bytes()).hexdigest(),'period':[days[0],days[-1]],'sessions':len(days),'results':results,'limitations':['2025 only: not OOS, no cross-year validation; no 2025-2026 exclusion possible','cost assumptions not actual dated account fills; open/close execution simulated','pretax USD; no FX; no interest on liquid cash or dividend receivables','end wealth includes unpaid SPY dividend entitlement, not wholly spendable cash','no deposit, futures, options or shorts; original sealed studies not executed']}
 (R/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
 for r in results:
  if r['cost_multiple']==1:print(r['strategy'], 'return',r['holding_return'],'Sharpe',r['sharpe_zero_cash'],'MDD',r['mdd'],'active',r['active_arithmetic_pa'],'CI',r['active_conditional_bootstrap_ci95'])
if __name__=='__main__':main()
