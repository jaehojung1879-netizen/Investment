from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path(__file__).resolve().parent;S=R.parent/'source_reconciliation_v1';repo=R.parents[2]
x=json.loads((R/'results.json').read_text());price=pd.read_csv(S/'outputs/market-price-source.csv');p=price.pivot(index='date',columns='ticker',values='close');D=pd.read_csv(S/'outputs/tax-2025-matched-distributions.csv');checks=0
for st in x['results']:
 name,k=st['strategy'],st['cost_multiple'];daily=pd.read_csv(R/f'{name}-{k}x-daily.csv');tr=pd.read_csv(R/f'{name}-{k}x-trades.csv');cash=100000.;q={'SPY':0,'BIL':0};pending=[]
 for row in daily.itertuples():
  day=row.date
  for ev in D[D.ex_date==day].itertuples():
   # Column8+ naming varies; select explicitly, not output's recorded cash amounts.
   dd=D[(D.ticker==ev.ticker)&(D.ex_date==day)].iloc[0];amount=q[ev.ticker]*dd['Total Distribution Per Share (11+12+13)']
   if amount:pending.append((dd.payment_date,amount))
  cash+=sum(a for pay,a in pending if pay<day);pending=[(pay,a) for pay,a in pending if pay>=day]
  for t in tr[tr.date==day].itertuples():
   assert t.shares>0 and t.shares==int(t.shares)
   sign=1 if t.side=='BUY' else -1;q[t.ticker]+=sign*t.shares;cash-=sign*t.shares*t.price+t.cost
   assert cash>=-1e-7 and q[t.ticker]>=0
  assert abs(cash-row.liquid_cash)<1e-7;assert q['SPY']==row.SPY_shares and q['BIL']==row.BIL_shares
  assert abs(sum(a for _,a in pending)-row.unpaid_receivable)<1e-7
  wealth=cash+sum(q[t]*p.loc[day,t] for t in q)+sum(a for _,a in pending);assert abs(wealth-row.wealth)<1e-7;checks+=1
 assert abs(st['holding_return']-(daily.iloc[-1].wealth/100000-1))<1e-12
 assert q=={'SPY':0,'BIL':0}
sig=pd.read_csv(R/'signal-audit.csv');assert (sig.signal_date<sig.execution_date).all()
# Preserve all earlier outputs and input bytes.
prior=json.loads((R.parent/'FILE-MANIFEST.json').read_text());assert all(hashlib.sha256((R.parent/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in prior['files'])
for f in json.loads((S/'SOURCE-MANIFEST.json').read_text())['records']:
 assert hashlib.sha256((repo/f['repository_relative_path']).read_bytes()).hexdigest()==f['sha256']
(R/'verification.json').write_text(json.dumps({'author_validation_only':True,'independent_saved_ledger_accounting_checks':checks,'signal_dates_all_strictly_before_trade':True,'negative_cash_or_short_positions':0,'terminal_positions_zero':True,'prior_sprint_87_and_source_manifest_preserved':True,'source':'official public ETF prices/distributions only','formal_study_execution':False},indent=2)+'\n');print(checks,'daily accounting checks pass; prior manifests unchanged')
