"""Independent summary algebra + public academic calculations. No pipeline imports.
Never opens internal price/ledger data; never imports or executes C2 machinery.
"""
from pathlib import Path
import json,hashlib,zipfile,re,io,math
import numpy as np
import pandas as pd
from scipy.stats import norm
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'; IN=ROOT/'inputs'
def save(name,x):
 (OUT/name).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False,default=str)+'\n')
def hac(x,lag=6):
 x=np.asarray(x,float);assert np.isfinite(x).all();n=len(x);m=x.mean();d=x-m
 v=np.dot(d,d)/n
 for k in range(1,min(lag,n-1)+1):v+=2*(1-k/(lag+1))*np.dot(d[k:],d[:-k])/n
 se=np.sqrt(max(v,0)/n);p=float(2*norm.sf(abs(m/se))) if se else (0. if m else 1.)
 return {'mean_pa':float(m*12),'se_pa':float(se*12),'ci95_pa':[float((m-1.959964*se)*12),float((m+1.959964*se)*12)],'p':p,'n':n,'hac_lag':lag}
def regression(excess,market,lag=6):
 y=np.asarray(excess,float);x=np.c_[np.ones(len(y)),np.asarray(market,float)];b=np.linalg.lstsq(x,y,rcond=None)[0];u=y-x@b;z=x*u[:,None];meat=z.T@z
 for k in range(1,min(lag,len(y)-1)+1):
  cross=z[k:].T@z[:-k];meat+=(1-k/(lag+1))*(cross+cross.T)
 bread=np.linalg.inv(x.T@x);cov=bread@meat@bread;se=np.sqrt(max(0,cov[0,0]))
 return {'alpha_pa':float(b[0]*12),'beta':float(b[1]),'alpha_ci95_pa':[float((b[0]-1.959964*se)*12),float((b[0]+1.959964*se)*12)],'scope':'US broad market only; no industry neutrality inferred'}

def holm(ps):
 order=np.argsort(ps);out=np.zeros(len(ps));last=0
 for rank,i in enumerate(order):last=max(last,min(1,(len(ps)-rank)*ps[i]));out[i]=last
 return out.tolist()
def stats(r,rf=None):
 r=np.asarray(r,float);ex=r if rf is None else r-np.asarray(rf,float);n=len(r);nav=np.r_[1,np.cumprod(1+r)]
 dd=nav/np.maximum.accumulate(nav)-1;end=int(dd.argmin());start=int(nav[:end+1].argmax());sd=ex.std(ddof=1);down=np.sqrt(np.mean(np.minimum(ex,0)**2))
 return {'cagr':float(nav[-1]**(12/n)-1),'arithmetic_excess_pa':float(ex.mean()*12),'vol_pa':float(sd*np.sqrt(12)),'sharpe':float(ex.mean()/sd*np.sqrt(12)) if sd else None,'sortino':float(ex.mean()/down*np.sqrt(12)) if down else None,'mdd':float(dd.min()),'worst_month':float(r.min()),'drawdown_start_offset':start,'drawdown_end_offset':end,'months':n}
def c2():
 raw=(IN/'c2'/'c2-fixed-exposure-attribution-v1-result.json').read_bytes();x=json.loads(raw)
 assert hashlib.sha256((IN/'c2-artifact.zip').read_bytes()).hexdigest()=='aea20cd755932baebbffc1174016c2466449994c84d03e6c31b5fddc33c1faa2'
 rows=[];sc=[];Y=x['years'];n=155;yr=x['byCost']['1x']['recent']['years'];oldY=Y-yr
 for cost,v in x['byCost'].items():
  dec=v['decomposition']['ZERO'];arith=(dec['selectionPpPerYear']+dec['exposurePpPerYear']+dec['costVsEtfPpPerYear'])/100
  log=math.log1p(v['c2']['cagr'])-math.log1p(v['etf']['cagr'])
  assert abs(arith-v['c2VsEtf']['arithmeticActive'])<1e-12
  assert abs(log-(arith+dec['jensenPpPerYear']/100))<1e-12
  rec=v['recent'];past={}
  for label,key in [('c2','c2Cagr'),('etf','etfCagr')]:
   past[label]=math.expm1((Y*math.log1p(v[label]['cagr'])-yr*math.log1p(rec[key]))/oldY)
  rows.append({'cost':cost,'c2_cagr':v['c2']['cagr'],'etf_cagr':v['etf']['cagr'],'cagr_gap':v['c2']['cagr']-v['etf']['cagr'],'arithmetic_active_pa':arith,'jensen_pa':log-arith,'log_growth_gap_pa':log,'c2_block_mdd':v['c2']['mdd'],'etf_block_mdd':v['etf']['mdd'],'recent_c2_cagr':rec['c2Cagr'],'recent_etf_cagr':rec['etfCagr'],'recent_gap':rec['c2Cagr']-rec['etfCagr'],'implied_prefix_c2_cagr':past['c2'],'implied_prefix_etf_cagr':past['etf'],'implied_prefix_gap':past['c2']-past['etf'],'allocated_prefix_years':oldY,'cost_drag_vs_etf_pa':dec['costVsEtfPpPerYear']/100})
  for name,s in v['scenarios'].items():
   g=s['selectionAnnualized'];net=s['netSelectionAnnualized'];d=v['decomposition'][name]
   assert abs(net['mean']-(g['mean']+d['costVsControlPpPerYear']/100))<1e-12
   ci=[net['mean']-1.959964*net['se'],net['mean']+1.959964*net['se']]
   assert np.allclose(ci,net['ci95'],rtol=0,atol=1e-13)
   recent=rec['scenarios'][name]['selectionAnnualized']['mean'];old=(g['mean']*Y-recent*yr)/oldY
   sc.append({'cost':cost,'cash_assumption':name,'gross_selection_pa':g['mean'],'net_c2_minus_control_pa':net['mean'],'net_ci95_pa':ci,'control_cagr':s['controlCagr'],'clip_transfer_pa':s['clipTransferPpPerYear']/100,'recent_GROSS_selection_pa':recent,'prefix_GROSS_selection_pa':old,'recent_NET_ci':None,'prefix_NET_ci':None})
 a=x['byCost']['1x']['scenarios'];sens={}
 for cost,v in x['byCost'].items():
  lo=v['scenarios']['BOK_POLICY_PROXY'];hi=v['scenarios']['BOK_POLICY_PLUS_100BP']
  sens[cost]={'gross_selection_change_pa':hi['selectionAnnualized']['mean']-lo['selectionAnnualized']['mean'],'net_selection_change_pa':hi['netSelectionAnnualized']['mean']-lo['netSelectionAnnualized']['mean'],'control_cagr_change':hi['controlCagr']-lo['controlCagr'],'ci_for_difference':None,'interpretation':'exact registered BOK times (1+.01*days/365) scenario difference; not arbitrary deposit repricing; drift/cost changes included in net'}
 turns=x['turnoverOneWayPerYear'];total=sum(turns.values());one=rows[0];gross=one['arithmetic_active_pa']-one['cost_drag_vs_etf_pa']
 save('c2-analysis.json',{'source_result_sha256':hashlib.sha256(raw).hexdigest(),'summary_checks':'summary identities and stored mean/SE CI reproduced without original calculator','path_table':rows,'scenario_table':sc,'cash_plus100bp_sensitivity':sens,'turnover':{**turns,'total_one_way_pa':total,'replacement_share':turns['replaced']/total,'additional_1bp_each_traded_side_pa':2*total*.0001,'arithmetic_etf_breakeven_cost_multiple':gross/(-one['cost_drag_vs_etf_pa'])},'limitations':['prefix is algebraic complement using full minus recent log wealth; duration allocated as total span minus stored recent span, not a new revaluation','MDD stored at block endpoints; not intrablock max loss','No raw block paths: recent net CI, prefix CI, 2025-2026 exclusion, annual/monthly outcomes, Sharpe/Sortino/beta/industry and arbitrary cash sensitivity unavailable','C2 is stock plus ETF residual; cash scenarios belong only to matched controls','costs are assumed tariffs, not realized fills']})
 pd.DataFrame(rows).to_csv(OUT/'c2-paths.csv',index=False);pd.DataFrame(sc).to_csv(OUT/'c2-scenarios.csv',index=False)
def french(name,daily=False):
 z=zipfile.ZipFile(IN/name);s=z.read(z.namelist()[0]).decode('utf-8-sig');rx=r'^\d{8},' if daily else r'^\d{6},';lines=s.splitlines();data=[s for s in lines if re.match(rx,s)]
 header=next(s for s in lines if s.startswith(',Mkt-RF') or s.startswith(',Mom'))
 df=pd.read_csv(io.StringIO(header+'\n'+'\n'.join(data)),index_col=0);df.index=pd.to_datetime(df.index.astype(str),format='%Y%m%d' if daily else '%Y%m').to_period('D' if daily else 'M');df.columns=df.columns.str.strip();df=df.apply(pd.to_numeric)/100
 assert df.index.is_unique and df.index.is_monotonic_increasing and not ((df<=-.99).any().any())
 return df
def aq(name,sheet,header,datekind='mixed'):
 df=pd.read_excel(IN/(name+'.xlsx'),sheet_name=sheet,header=header);col=df.columns[0]
 if datekind=='yyyymm':dates=pd.to_datetime(df[col].astype(str).str.replace(r'\.0$','',regex=True),format='%Y%m',errors='coerce')
 else:dates=pd.to_datetime(df[col],format='mixed',errors='coerce')
 df=df.loc[dates.notna()].copy();df.index=pd.DatetimeIndex(dates[dates.notna()]).to_period('M');df=df.drop(columns=[col]);df=df.apply(pd.to_numeric,errors='coerce')
 assert df.index.is_unique and df.index.is_monotonic_increasing
 return df
def factors(ff):
 data={};original={}
 sources=[('TSMOM','Time-Series-Momentum-Factors-Monthly','TSMOM Factors',17,'TSMOM'),('BAB_US','Betting-Against-Beta-Equity-Factors-Monthly','BAB Factors',18,'USA'),('BAB_GLOBAL','Betting-Against-Beta-Equity-Factors-Monthly','BAB Factors',18,'Global'),('QMJ_US','Quality-Minus-Junk-Factors-Monthly','QMJ Factors',18,'USA'),('QMJ_GLOBAL','Quality-Minus-Junk-Factors-Monthly','QMJ Factors',18,'Global'),('VME_VAL','Value-and-Momentum-Everywhere-Factors-Monthly','VME Factors',21,'VAL'),('VME_MOM','Value-and-Momentum-Everywhere-Factors-Monthly','VME Factors',21,'MOM')]
 for label,file,sheet,head,col in sources:
  # First sheet is publisher's main factor sheet; verify the named series below.
  d=aq(file,0,head);data[label]=d[col].dropna()
 for col in ['SMB','HML','RMW','CMA']:data['FF_'+col]=ff[col]
 original['TSMOM_ORIGINAL']=aq('Time-Series-Momentum-Original-Paper-Data',0,10)['TSMOM'].dropna()
 b=aq('Betting-Against-Beta-Original-Paper-Data',0,10,'yyyymm');original['BAB_US_ORIGINAL']=b['U.S. Equities'].dropna();original['BAB_ALL_ORIGINAL']=b['All Assets'].dropna()
 v=aq('Value-and-Momentum-Everywhere-Original-Paper-Data','VME Factors',14);original['VME_VAL_ORIGINAL']=v['VAL'].dropna();original['VME_MOM_ORIGINAL']=v['MOM'].dropna()
 pd.DataFrame(original).to_csv(OUT/'academic-original-monthly.csv')
 rows=[];annual=[];monthly=pd.DataFrame(data);monthly.to_csv(OUT/'academic-monthly.csv')
 for label,s in {**data,**original}.items():
  s=s[s.index<=pd.Period('2026-10','M')];assert (s>-.99).all()
  # Missing periods must be reported, not compressed into false regular observations.
  expected=pd.period_range(s.index.min(),s.index.max(),freq='M');assert s.index.equals(expected)
  row={'series':label,'sample_start':str(s.index.min()),'sample_end':str(s.index.max()),'evidence':'PUBLISHED_FACTOR_ORIGINAL' if label in original else 'PUBLISHED_FACTOR_UPDATED','not_implementable_net':True,**stats(s),**hac(s,6)}
  row['index_cagr_convention']='compound 1+published excess factor; unfunded normalized factor index, not investor CAGR'
  pre=s[s.index<pd.Period('2025-01','M')];row['excluding_2025_2026']=stats(pre)
  rec=s[s.index>=pd.Period('2024-01','M')];row['recent_2024_plus']=stats(rec) if len(rec)>1 else None
  # Common window for current factors, without forcing stale AQR endpoints forward.
  common=s[(s.index>=pd.Period('2013-01','M'))&(s.index<=pd.Period('2026-05','M'))];row['common_2013_202605']=stats(common) if len(common)>1 else None
  rows.append(row)
  for y,g in s.groupby(s.index.year):annual.append({'series':label,'year':int(y),'months':len(g),'factor_index_return':float(np.prod(1+g)-1)})
 ps=[r['p'] for r in rows if r['series'] in data]+[1.,1.];adj=holm(ps)
 for r,a in zip([r for r in rows if r['series'] in data],adj):r['holm_13_p']=a
 pd.DataFrame(annual).to_csv(OUT/'academic-annual.csv',index=False)
 save('academic-factors.json',{'factor_family_slots':13,'unavailable_slots':['Novy-Marx gross profitability (FF RMW is operating profitability, NOT exact GP)','Gu/Kelly/Xiu: no official prediction panel/code obtained; no ML premium inferred'],'rows':rows,'cost_1x_2x_3x':None,'cost_reason':'factor-level monthly returns contain no holdings, turnover, fills, borrow or margin ledger; no defensible net estimate'})
 return data
def simulate(weights,market_excess,rf,multiple,borrow_pa=.01):
 returns=[];trades=[];borrow=[];prev=0.
 for wi,mi,rfi in zip(weights,market_excess,rf):
  k=multiple*.001;fee=0.
  # Fund transaction costs from wealth BEFORE setting post-cost target weights.
  # Contraction holds even for original-replication leverage (< 1/k).
  for _ in range(200):
   new=k*abs(wi*(1-fee)-prev)
   if abs(new-fee)<1e-15:fee=new;break
   fee=new
  else:raise ValueError('COST_FIXED_POINT_DID_NOT_CONVERGE')
  trade=abs(wi*(1-fee)-prev)
  bor=(borrow_pa/12*max(-wi,0)) if multiple else 0.
  growth=(1-fee)*(1+rfi+wi*mi-bor);assert growth>0
  returns.append(growth-1);trades.append(trade);borrow.append((1-fee)*bor)
  prev=wi*(1-fee)*(1+rfi+mi)/growth
 return np.asarray(returns),trades,borrow

def public_strategies(ff,daily):
 # Direct implementation of Moreira-Muir monthly realized variance of daily market excess.
 rv=daily['Mkt-RF'].groupby(daily.index.asfreq('M')).var(ddof=0)
 frame=ff[['Mkt-RF','RF']].copy();frame['prev_var']=rv.reindex(frame.index).shift(1)
 frame['prev_rv_sum']=(daily['Mkt-RF'].groupby(daily.index.asfreq('M')).apply(lambda x: float(np.sum((x-x.mean())**2)))).reindex(frame.index).shift(1)
 frame['trend']=((1+frame['Mkt-RF']).rolling(12,min_periods=12).apply(np.prod,raw=True)-1).shift(1)
 frame=frame.loc['1964-07':'2026-10'].dropna();assert frame.index.equals(pd.period_range(frame.index[0],frame.index[-1],freq='M'))
 m=frame['Mkt-RF'].to_numpy();rf=frame['RF'].to_numpy();trend=frame['trend'].to_numpy();pv=frame['prev_var'].to_numpy();rvsum=frame['prev_rv_sum'].to_numpy();c=np.std(m,ddof=1)/np.std(m/rvsum,ddof=1)
 weights={'MARKET100':np.ones(len(m)),'MARKET80_RF20':np.full(len(m),.8),'MARKET60_RF40':np.full(len(m),.6),'TREND12_LONG_CASH':(trend>0).astype(float),'TREND12_LONG_SHORT':np.where(trend>0,1.,-1.),'VOL_TARGET10_CAP1':np.minimum(1,.1/np.sqrt(pv*252)),'MM17_ORIGINAL_NORMALIZATION':c/rvsum}
 results=[];paths={};series_out=pd.DataFrame(index=frame.index);weight_out=pd.DataFrame(weights,index=frame.index);weight_out.to_csv(OUT/'public-proxy-weights.csv')
 for name,w in weights.items():
  for multiple in [0,1,2,3]:
   returns,trades,borrow=simulate(w,m,rf,multiple)
   r=np.asarray(returns);base=rf+m;ex=r-base;row={'strategy':name,'cost_multiple':multiple,'start':str(frame.index[0]),'end':str(frame.index[-1]),**stats(r,rf), 'active_vs_public_market':hac(ex),'gross_exposure_max':float(abs(w).max()),'avg_exposure':float(w.mean()),'annual_traded_notional':float(np.mean(trades)*12),'annual_borrow_drag':float(np.mean(borrow)*12),'investable':False,'leverage_reject':bool(np.max(abs(w))>1),'average_short_weight':float(np.mean(np.maximum(-w,0)))}
   row['market_attribution']=regression(r-rf,m)
   row['drawdown_start_month']=str(frame.index[0]-1+row['drawdown_start_offset'])
   row['drawdown_trough_month']=str(frame.index[0]-1+row['drawdown_end_offset'])
   for period,mask in [('excluding_2025_2026',frame.index<pd.Period('2025-01','M')),('recent_2024_plus',frame.index>=pd.Period('2024-01','M'))]:row[period]={**stats(r[mask],rf[mask]),'active':hac(ex[mask])}
   # Risk matching by reducing the higher-vol side; full-sample descriptive comparison only.
   ve=np.std(r-rf,ddof=1);vb=np.std(m,ddof=1);target=min(ve,vb);a=target/ve;b=target/vb
   rm=rf+a*(r-rf);bm=rf+b*m
   row['equal_vol_DESCRIPTIVE']={'strategy_scale':float(a),'market_scale':float(b),'cagr_gap':stats(rm,rf)['cagr']-stats(bm,rf)['cagr'],'active':hac(rm-bm)}
   results.append(row);paths[(name,multiple)]=r;series_out[name+'_'+str(multiple)+'x']=r
 for multiple in [0,1,2,3]:
  rr=[r for r in results if r['cost_multiple']==multiple and r['strategy']!='MARKET100'];pa=holm([r['active_vs_public_market']['p'] for r in rr])
  for r,p in zip(rr,pa):r['holm_6_p']=p
 longcash=paths[('TREND12_LONG_CASH',1)];longshort=paths[('TREND12_LONG_SHORT',1)];mask=weights['TREND12_LONG_SHORT']<0
 neg=np.flatnonzero(mask);worst=neg[np.argmin(longshort[mask])];best_rebound=neg[np.argmax(m[mask])]
 increment={'net_1x_longshort_minus_longcash':hac(longshort-longcash),'cagr_gap':stats(longshort,rf)['cagr']-stats(longcash,rf)['cagr'],'short_months':int(mask.sum()),'worst_short_month':str(frame.index[worst]),'worst_short_month_return':float(longshort[worst]),'strongest_market_rebound_while_short':{'month':str(frame.index[best_rebound]),'market_return':float((m+rf)[best_rebound]),'longshort_return':float(longshort[best_rebound]),'longcash_return':float(longcash[best_rebound])}}
 series_out.to_csv(OUT/'public-proxy-monthly.csv');annual=[]
 for (name,k),r in paths.items():
  s=pd.Series(r,index=frame.index)
  for y,g in s.groupby(s.index.year):annual.append({'strategy':name,'cost_multiple':k,'year':int(y),'months':len(g),'return':float(np.prod(1+g)-1)})
 pd.DataFrame(annual).to_csv(OUT/'public-proxy-annual.csv',index=False)
 save('public-proxy-strategies.json',{'scope':'PUBLIC_FRENCH_US_MARKET_AND_TBILL_FACTOR_PROXY_NOT_SPY_OR_DEPOSIT','frozen_family_sha256':hashlib.sha256((ROOT/'family.json').read_bytes()).hexdigest(),'mm17_c':float(c),'mm17_c_uses_full_sample':True,'rows':results,'longshort_increment':increment,'margin_collateral_liquidation':'NOT_IDENTIFIABLE from monthly factor returns; monthly solvent does not establish intramonth solvency; no futures or options implementation asserted','costs':'illustrative 10bp one-way times 1/2/3; fixed 100bp annual short borrow when multiplier>0; no verified spread, funding haircut, locate or execution availability'})
 return results
if __name__=='__main__':
 c2();ff=french('ff5.zip');daily=french('ff_daily.zip',True);factors(ff);rows=public_strategies(ff,daily)
 for r in rows:
  if r['cost_multiple']==1:print(r['strategy'],round(r['cagr']*100,3),round(r['sharpe'],3),round(r['mdd']*100,3),round(r['active_vs_public_market']['mean_pa']*100,3),r.get('holm_6_p'))
 print('DONE: public academic and artifact-summary calculations only')
