"""Bounded read-only acquisition from the two user-selected academic publishers."""
from pathlib import Path
import urllib.request, json, hashlib, datetime, re
ROOT=Path(__file__).resolve().parent
URLS={
 'ff5.zip':'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_5_Factors_2x3_CSV.zip',
 'momentum.zip':'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Momentum_Factor_CSV.zip',
 'ff5_description.html':'https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_5_factors_2x3.html',
 'bab.html':'https://www.aqr.com/Insights/Datasets/Betting-Against-Beta-Equity-Factors-Monthly',
 'qmj.html':'https://www.aqr.com/Insights/Datasets/Quality-Minus-Junk-Factors-Monthly',
 'tsmom.html':'https://www.aqr.com/Insights/Datasets/Time-Series-Momentum-Factors-Monthly',
 'vam.html':'https://www.aqr.com/Insights/Datasets/Value-and-Momentum-Everywhere-Factors-Monthly',
}
def fetch(name,url):
 p=ROOT/'inputs'/name
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (academic replication)'})
  with urllib.request.urlopen(req,timeout=40) as r:
   raw=r.read(); status=r.status; final=r.url
  p.write_bytes(raw)
  return dict(name=name,url=url,final_url=final,status=status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except Exception as e:return dict(name=name,url=url,error=str(e))
if __name__=='__main__':
 from concurrent.futures import ThreadPoolExecutor
 with ThreadPoolExecutor(max_workers=4) as pool: receipts=list(pool.map(lambda kv:fetch(*kv), URLS.items()))
 for rec in receipts:
  print(rec['name'],rec.get('status',rec.get('error')),rec.get('bytes'))
  if rec['name'].endswith('.html') and rec.get('status')==200:
   s=(ROOT/'inputs'/rec['name']).read_text(errors='replace')
   links=sorted(set(re.findall(r'[^\s"<>]+\.xlsx(?:\?[^\s"<>]*)?',s)))
   for link in links:print('XLSX',link)
 (ROOT/'outputs'/'public-acquisition.json').write_text(json.dumps(receipts,indent=2))
